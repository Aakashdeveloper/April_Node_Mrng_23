const axios = require('axios')

exports.handler = (event,context,callback) => {

    if (event.queryStringParameters && event.queryStringParameters.city) {
        console.log("Received base: " + event.queryStringParameters.city);
        city = event.queryStringParameters.city;
    }


    axios.get(`http://api.openweathermap.org/data/2.5/forecast/daily?q=${city}&mode=json&units=metric&cnt=5&appid=fbf712a5a83d7305c3cda4ca8fe7ef29`).then((response) => {
        var final = response.data.city

        callback(null, {"statusCode":200, "output":JSON.stringify(final)})
    })
}
